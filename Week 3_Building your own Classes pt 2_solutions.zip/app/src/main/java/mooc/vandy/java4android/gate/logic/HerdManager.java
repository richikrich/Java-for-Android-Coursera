package mooc.vandy.java4android.gate.logic;

import java.util.Random;

import mooc.vandy.java4android.gate.ui.OutputInterface;

/**
 * This class uses your Gate class to manage a herd of snails.  We
 * have supplied you will the code necessary to execute as an app.
 * You must fill in the missing logic below.
 */
public class HerdManager {
    /**
     * Reference to the output.
     */
    private OutputInterface mOut;

    /**
     * The input Gate object.
     */
    private Gate mEastGate;

    /**
     * The output Gate object.
     */
    private Gate mWestGate;

    /**
     * Maximum number of iterations to run the simulation.
     */
    private static final int MAX_ITERATIONS = 10;

    /**
     * Constructor initializes the fields.
     */
    public HerdManager(OutputInterface out,
                       Gate westGate,
                       Gate eastGate) {
        mOut = out;

        mWestGate = westGate;
        mWestGate.open(Gate.IN);

        mEastGate = eastGate;
        mEastGate.open(Gate.OUT);
    }

    // TODO -- Fill your code in here
    public static final int HERD = 24;

    public void simulateHerd(Random rand)
    {
        int inPen=HERD;
        int inPasture=0;
        int randomNumber;
        int movedIn;
        boolean randBool;
        mOut.println("There are currently " + inPen + " snails in the pen and " + inPasture +" snails in the pasture\n");
        for(int i=0; i<MAX_ITERATIONS; i++)
        {
            if(inPasture==0)
            {
                randomNumber=rand.nextInt(inPen)+1;
                movedIn=mEastGate.thru(randomNumber);
            }
            else if (inPen==0)
            {
                randomNumber=rand.nextInt(inPasture)+1;
                movedIn=mWestGate.thru(randomNumber);
            }
            else
            {
                randBool=rand.nextBoolean();
                if(randBool==true)
                {
                    randomNumber=rand.nextInt(inPen)+1;
                    movedIn=mEastGate.thru(randomNumber);
                }
                else
                {
                    randomNumber=rand.nextInt(inPasture)+1;
                    movedIn=mWestGate.thru(randomNumber);
                }
            }
            inPen+=movedIn;
            inPasture-=movedIn;
            mOut.println("There are currently " + inPen + " snails in the pen and " + inPasture +" snails in the pasture\n");
        }
    }

}
